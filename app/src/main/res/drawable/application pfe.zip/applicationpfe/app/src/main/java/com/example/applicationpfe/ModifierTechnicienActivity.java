package com.example.applicationpfe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ModifierTechnicienActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_technicien);
        // Assurez-vous d'initialiser FirebaseApp au préalable

// Récupérer l'ID du technicien connecté
        String technicianId = FirebaseAuth.getInstance().getCurrentUser().getUid();

// Récupérer une référence à la base de données Firebase
        DatabaseReference technicianRef = FirebaseDatabase.getInstance().getReference().child("technicians").child(technicianId);

        technicianRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Récupérer les valeurs des champs
                    String nom = dataSnapshot.child("nom").getValue(String.class);
                    String email = dataSnapshot.child("email").getValue(String.class);
                    String ville = dataSnapshot.child("ville").getValue(String.class);
                    String telephone = dataSnapshot.child("telephone").getValue(String.class);

                    // Faire quelque chose avec les informations récupérées
                    // Par exemple, mettre à jour les champs de texte dans l'interface utilisateur
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Gérer les erreurs de lecture depuis Firebase
            }
        });
    }
}