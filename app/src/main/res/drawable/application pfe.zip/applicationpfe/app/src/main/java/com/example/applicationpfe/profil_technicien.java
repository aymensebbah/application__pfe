package com.example.applicationpfe;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class profil_technicien  extends AppCompatActivity {

    private TextView textViewName;
    private TextView textViewEmail;
    private TextView textViewVille;
    private TextView textViewTelephone;
    private Button buttonModifier;
    private Button buttonRetour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_technicien);

        textViewName = findViewById(R.id.textViewName);
        textViewEmail = findViewById(R.id.textViewEmail);
        textViewVille = findViewById(R.id.textViewVille);
        textViewTelephone = findViewById(R.id.textViewTelephone);
        buttonModifier = findViewById(R.id.buttonModifier);
        buttonRetour = findViewById(R.id.buttonRetour);

        // Récupérer les informations du technicien depuis la source de données (par exemple, Firebase)
        // Assurez-vous d'initialiser FirebaseApp au préalable

// Récupérer l'ID du technicien connecté
        String technicianId = FirebaseAuth.getInstance().getCurrentUser().getUid();

// Récupérer une référence à la base de données Firebase
        DatabaseReference technicianRef = FirebaseDatabase.getInstance().getReference().child("technicians").child(technicianId);

        technicianRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Récupérer les valeurs des champs
                    String nom = dataSnapshot.child("nom").getValue(String.class);
                    String email = dataSnapshot.child("email").getValue(String.class);
                    String ville = dataSnapshot.child("ville").getValue(String.class);
                    String telephone = dataSnapshot.child("telephone").getValue(String.class);

                    // Faire quelque chose avec les informations récupérées
                    // Par exemple, mettre à jour les champs de texte dans l'interface utilisateur
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Gérer les erreurs de lecture depuis Firebase
            }
        });

        // Mettre à jour les TextView avec les informations du technicien

        // Ajouter un listener au bouton "Modifier les informations"

        buttonModifier.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfilTechnicienActivity.this, ModifierTechnicienActivity.class);
                    startActivity(intent);
                }
            });

        // Ajouter un listener au bouton "Retour"
        buttonRetour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ajouter le code pour retourner à l'activité précédente
                onBackPressed();
            }
        });
    }
}