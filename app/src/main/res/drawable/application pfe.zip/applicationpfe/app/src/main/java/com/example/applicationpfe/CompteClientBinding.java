package com.example.applicationpfe;

import android.view.LayoutInflater;
import android.widget.Adapter;
import android.widget.AdapterView;

public class CompteClientBinding {
    public AdapterView<Adapter> bottomNavigationView;

    public static CompteClientBinding inflate(LayoutInflater layoutInflater) {
    }

    public int getRoot() {
    }
}
