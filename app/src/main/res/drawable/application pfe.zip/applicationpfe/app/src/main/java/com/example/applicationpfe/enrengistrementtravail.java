package com.example.applicationpfe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class enrengistrementtravail extends AppCompatActivity {
    private EditText etTitle, etDescription,etnomclient, etDate,ettype,ettypelocalisation;
    private Button btnSubmit;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enrengistrementtravail);
        // Référencer les vues
        etTitle = findViewById(R.id.edit_title);
        etnomclient= findViewById(R.id.edit_description);
        etDate = findViewById(R.id.edit_date);
        ettype= findViewById(R.id.edit_typetravail);
        ettypelocalisation= findViewById(R.id.edit_localisation);
        btnSubmit = findViewById(R.id.btn_submit);
        // Obtenir une référence à la base de données Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("travaux");

        // Définir un événement de clic sur le bouton Soumettre
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Récupérer les informations saisies par le technicien
                String title = etTitle.getText().toString();
                String nomclient = etnomclient.getText().toString();
                String date = etDate.getText().toString();
                String type=ettype.getText().toString();
                        String localisation = ettypelocalisation.getText().toString();
                // Enregistrer les données saisies dans la base de données Firebase
                String workId = databaseReference.push().getKey(); // Générer une clé unique pour le travail
                Travail tarvail = new Travail(workId, title, nomclient, date,type,localisation);
                databaseReference.child(workId).setValue(tarvail);
                // Réinitialiser les champs de formulaire après soumission
                etTitle.setText("");
                etnomclient.setText("");
                etDate.setText("");
                ettype.setText("");
                ettypelocalisation.setText("");;


            }
}}}