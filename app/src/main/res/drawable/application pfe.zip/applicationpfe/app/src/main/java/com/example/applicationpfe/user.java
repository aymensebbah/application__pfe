package com.example.applicationpfe;

public class user {
    public static String getUid() {
    }
}
