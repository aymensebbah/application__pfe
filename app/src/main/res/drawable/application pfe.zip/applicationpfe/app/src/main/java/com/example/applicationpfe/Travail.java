package com.example.applicationpfe;

public class Travail {
    private String workId;
    private String title;
    private String nomclient;
    private String date;
    private String typeentretien;
    private String localisation;
    public Travail() {
        // Constructeur vide requis pour Firebase
    }

    public Travail(String workId, String title, String description, String date,String typeentretien,String localisation) {
        this.workId = workId;
        this.title = title;
        this.nomclient = nomclient;
        this.date = date;
        this.typeentretien=typeentretien;
        this.localisation=localisation;
    }
    // Définir les getters et les setters pour chaque propriété
    // ...

    // Exemple de méthode toString() pour afficher les détails du travail
    @Override
    public String toString() {
        return "Work{" +
                "workId='" + workId + '\'' +
                ", title='" + title + '\'' +
                ",nomclient ='" + nomclient + '\'' +
                ", typeentretien='" + typeentretien + '\'' +
                ", localisation='" + localisation + '\'' +
                ", date='" + date + '\'' +
                '}';

    }

    public char getTitle() {
        return 0;
    }

    public char getnomclient() {
        return 0;
    }

    public int getDate() {
        return 0;
    }

    public char gettypeentretien() {
        return 0;
    }

    public char getlocalisation() {
        return 0;
    }
}
