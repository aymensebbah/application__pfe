package com.example.applicationpfe;

public class Technicien {
    private String name;
    private String prenom;
    private double latitude;
    private double longitude;

    public Technicien(String name,String  prenom,  double latitude, double longitude) {
        this.name = name;
        this.prenom = prenom;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getNom() {
    }

    public char getLocalisation() {
        return 0;
    }

    public int getDistance() {
    }

    public String getCin() {
    }
    public String  getPrenom(){
        return prenom;}
}
