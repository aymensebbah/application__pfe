package com.example.applicationpfe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

public class ModifierClientActivity extends AppCompatActivity {

    private EditText editTextNom;
    private EditText editTextEmail;
    private EditText editTextVille;
    private EditText editTextTelephone;
    private Button buttonEnregistrer;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_profil);

        editTextNom = findViewById(R.id.editTextNom);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextVille = findViewById(R.id.editTextVille);
        editTextTelephone = findViewById(R.id.editTextTelephone);
        buttonEnregistrer = findViewById(R.id.buttonEnregistrer);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Récupérer les informations actuelles du client
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference clientRef = mDatabase.child("clients").child(userId);
            clientRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        // Récupérer les valeurs actuelles des champs du client
                        String nom = snapshot.child("nom").getValue(String.class);
                        String email = snapshot.child("email").getValue(String.class);
                        String ville = snapshot.child("ville").getValue(String.class);
                        String telephone = snapshot.child("telephone").getValue(String.class);

                        // Afficher les informations actuelles dans les champs de saisie
                        editTextNom.setText(nom);
                        editTextEmail.setText(email);
                        editTextVille.setText(ville);
                        editTextTelephone.setText(telephone);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Gérer les erreurs de lecture depuis Firebase
                    Log.e("Firebase", "Erreur lors de la lecture depuis Firebase : " + error.getMessage());
                    Toast.makeText(ModifierClientActivity.this, "Erreur lors de la lecture depuis Firebase", Toast.LENGTH_SHORT).show();
                }
            });
        }

        buttonEnregistrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enregistrerModifications();
            }
        });
    }

    private void enregistrerModifications() {
        // Récupérer les nouvelles valeurs des champs de saisie
        String nom = editTextNom.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String ville = editTextVille.getText().toString().trim();
        String telephone = editTextTelephone.getText().toString().trim();

        // Vérifier si les champs sont valides (par exemple, non vides)
        if (nom.isEmpty() || email.isEmpty() || ville.isEmpty() || telephone.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        // Mettre à jour les informations du client dans la base de données Firebase
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference clientRef = mDatabase.child("clients").child(userId);
            clientRef.child("nom").setValue(nom);
            clientRef.child("email").setValue(email);
            clientRef.child("ville").setValue(ville);
            clientRef.child("telephone").setValue(telephone)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(ModifierClientActivity.this, "Modifications enregistrées", Toast.LENGTH_SHORT).show();
                                finish(); // Fermer l'activité de modification après l'enregistrement des modifications
                            } else {
                                Toast.makeText(ModifierClientActivity.this, "Erreur lors de la sauvegarde des modifications", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }
}