import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.Fragment;

import com.example.applicationpfe.DemandeIntervention;
import com.example.applicationpfe.R;

public class demande_frag extends Fragment {

    private Button button;

    public demande_frag() {
        // Constructeur vide requis pour les fragments
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_demande_frag, container, false);

        button = view.findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Créez une intention pour lancer l'activité DemandeInterventionActivity
                Intent intent = new Intent(getActivity(), DemandeIntervention.class);
                startActivity(intent);
            }
        });

        return view;
    }
}