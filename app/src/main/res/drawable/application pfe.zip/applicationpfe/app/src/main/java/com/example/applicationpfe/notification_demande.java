package com.example.applicationpfe;
notification_demande

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.RemoteMessage;

import java.util.ArrayList;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private static final String TAG = "NotificationsActivity";

    private RecyclerView notificationsRecyclerView;
    private NotificationsAdapter notificationsAdapter;
    private List<String> notificationsList;

    private FirebaseFirestore db;
    private CollectionReference notificationsCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        // Récupérer la référence du RecyclerView à partir du fichier de mise en page XML
        notificationsRecyclerView = findViewById(R.id.notificationsRecyclerView);

        // Initialiser Firebase Firestore
        db = FirebaseFirestore.getInstance();

        // Obtenir la référence de la collection "notifications" dans Firestore
        notificationsCollection = db.collection("notifications");

        // Initialiser la liste des notifications
        notificationsList = new ArrayList<>();

        // Créer un adaptateur pour les notifications
        notificationsAdapter = new NotificationsAdapter(notificationsList);

        // Ajouter des exemples de notifications (remplacez cela par la récupération réelle des notifications depuis Firebase)
        notificationsList.add(new Notification("Notification 1", "Contenu de la notification 1"));
        notificationsList.add(new Notification("Notification 2", "Contenu de la notification 2"));
        notificationsList.add(new Notification("Notification 3", "Contenu de la notification 3"));


        // Définir le gestionnaire de disposition du RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        notificationsRecyclerView.setLayoutManager(layoutManager);

        // Définir l'adaptateur du RecyclerView
        notificationsRecyclerView.setAdapter(notificationsAdapter);

        // Interroger la collection "notifications" pour obtenir toutes les notifications
        Query query = notificationsCollection.orderBy("timestamp", Query.Direction.DESCENDING);

        // Écouter les modifications dans la collection des notifications
        query.addSnapshotListener((querySnapshot, error) -> {
            if (error != null) {
                // En cas d'erreur lors de la récupération des notifications
                Log.e(TAG, "Error getting notifications: " + error.getMessage());
                return;
            }

            if (querySnapshot != null) {
                // Effacer la liste des notifications existantes
                notificationsList.clear();

                // Parcourir les modifications dans le résultat de la requête
                for (DocumentChange documentChange : querySnapshot.getDocumentChanges()) {
                    DocumentSnapshot document = documentChange.getDocument();

                    // Vérifier si le document existe
                    if (document.exists()) {
                        // Récupérer le texte de la notification à partir du champ "message" du document
                        String notificationText = document.getString("message");

                        // Ajouter le texte de la notification à la liste des notifications
                        notificationsList.add(notificationText);
                    }
                }

                // Avertir l'adaptateur que les données ont changé
                notificationsAdapter.notifyDataSetChanged();
            }
        });
    }
}